<div class="navbar-social pull-right visible-md visible-lg">
    <div class="g-follow" data-href="//plus.google.com/102208318944585363303" data-annotation="bubble" data-height="20" data-rel="publisher"></div>
</div>
<div class="navbar-social pull-right visible-md visible-lg">
    <div class="fb-like" data-href="<?php echo e(\App\Option::getvalue('fb_fanpage')); ?>" data-layout="button_count" data-action="like" data-show-faces="false" data-share="false"></div>
</div>