Subject: {{ $subject }}
Name: {{ $name }} <{{ $email  }}>
Message:

{{ $messageTxt }}

--- From {{ url('/') }} ---